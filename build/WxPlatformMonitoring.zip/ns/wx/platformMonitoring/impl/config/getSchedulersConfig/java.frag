<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getSchedulersConfig</value>
  <array name="sig" type="value" depth="1">
    <value>[o] recref:0:required schedulerMonitoringConfig wx.platformMonitoring.impl.scheduler:SchedulerMonitoringConfig</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">SnNvblZhbHVlIGNvbmZpZ1NjaGVkdWxlcnMgPSBnZXRDb25maWcoInNjaGVkdWxlcnMuanNvbiIp
Ow0KSnNvbkFycmF5IGpTY2hlZHVsZXJzID0gY29uZmlnU2NoZWR1bGVycy5hc09iamVjdCgpLmdl
dCgic2NoZWR1bGVycyIpLmFzQXJyYXkoKTsNCi8vIHBpcGVsaW5lDQpJRGF0YUN1cnNvciBwaXBl
bGluZUN1cnNvciA9IHBpcGVsaW5lLmdldEN1cnNvcigpOw0KLy8gc2NoZWR1bGVyTW9uaXRvcmlu
Z0NvbmZpZw0KSURhdGEJc2NoZWR1bGVyTW9uaXRvcmluZ0NvbmZpZyA9IElEYXRhRmFjdG9yeS5j
cmVhdGUoKTsNCklEYXRhQ3Vyc29yIHNjaGVkdWxlck1vbml0b3JpbmdDb25maWdDdXJzb3IgPSBz
Y2hlZHVsZXJNb25pdG9yaW5nQ29uZmlnLmdldEN1cnNvcigpOw0KU3RyaW5nW10Jc2NoZWR1bGVy
cyA9IG5ldyBTdHJpbmdbalNjaGVkdWxlcnMuc2l6ZSgpXTsNCmZvciggaW50IGk9MDsgaTxzY2hl
ZHVsZXJzLmxlbmd0aDsgaSsrICkgew0KCXNjaGVkdWxlcnNbaV0gPSBqU2NoZWR1bGVycy5nZXQo
aSkuYXNTdHJpbmcoKTsNCn0NCklEYXRhVXRpbC5wdXQoIHNjaGVkdWxlck1vbml0b3JpbmdDb25m
aWdDdXJzb3IsICJzY2hlZHVsZXJzIiwgc2NoZWR1bGVycyApOw0Kc2NoZWR1bGVyTW9uaXRvcmlu
Z0NvbmZpZ0N1cnNvci5kZXN0cm95KCk7DQpJRGF0YVV0aWwucHV0KCBwaXBlbGluZUN1cnNvciwg
InNjaGVkdWxlck1vbml0b3JpbmdDb25maWciLCBzY2hlZHVsZXJNb25pdG9yaW5nQ29uZmlnICk7
DQpwaXBlbGluZUN1cnNvci5kZXN0cm95KCk7DQoNCg0K</value>
</Values>
