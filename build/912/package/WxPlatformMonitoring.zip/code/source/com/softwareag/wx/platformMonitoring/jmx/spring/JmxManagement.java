package com.softwareag.wx.platformMonitoring.jmx.spring;

import java.util.HashMap;
import java.util.Map;

import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jmx.export.MBeanExporter;
import org.springframework.jmx.support.MBeanServerFactoryBean;

public class JmxManagement {

	public void init() {
		org.springframework.jmx.export.MBeanExporter e = new org.springframework.jmx.export.MBeanExporter();
		System.out.println("------------ registering bean");
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		e.setBeanFactory(context.getParentBeanFactory());

		org.springframework.jmx.support.MBeanServerFactoryBean mServer = new MBeanServerFactoryBean();
		mServer.setLocateExistingServerIfPossible(true);
		mServer.afterPropertiesSet();
		
		e.setAllowEagerInit(true);
		e.setServer(mServer.getObject());
		System.out.println("------------ registering bean count " + e.getServer().getMBeanCount() + ", default: "
				+ e.getServer().getDefaultDomain());
	}
	

	
}
