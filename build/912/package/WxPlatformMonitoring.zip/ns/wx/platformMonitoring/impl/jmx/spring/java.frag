<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">spring</value>
  <value name="encodeutf8">true</value>
  <value name="body">Y29tLnNvZnR3YXJlYWcud3gucGxhdGZvcm1Nb25pdG9yaW5nLmpteC5zcHJpbmcuSm14TWFuYWdl
bWVudCBqID0gbmV3IGNvbS5zb2Z0d2FyZWFnLnd4LnBsYXRmb3JtTW9uaXRvcmluZy5qbXguc3By
aW5nLkpteE1hbmFnZW1lbnQoKTsNCmouaW5pdCgpOw==</value>
</Values>
