<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getOnedataConfig</value>
  <array name="sig" type="value" depth="1">
    <value>[o] recref:0:required onedataConnectionData wx.platformMonitoring.impl.onedata:OnedataConnectionData</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">SnNvblZhbHVlIGNvbmZpZ09uZWRhdGEgPSBnZXRDb25maWcoIm9uZWRhdGEuanNvbiIpOw0KSnNv
bk9iamVjdCBvbmVkYXRhID0gY29uZmlnT25lZGF0YS5hc09iamVjdCgpLmdldCgib25lZGF0YSIp
LmFzT2JqZWN0KCkuZ2V0KCJjb25maWciKS5hc09iamVjdCgpOw0KLy8gcGlwZWxpbmUNCklEYXRh
Q3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7DQovLyBvbmVkYXRh
Q29ubmVjdGlvbkRhdGENCklEYXRhCW9uZWRhdGFDb25uZWN0aW9uRGF0YSA9IElEYXRhRmFjdG9y
eS5jcmVhdGUoKTsNCklEYXRhQ3Vyc29yIG9uZWRhdGFDb25uZWN0aW9uRGF0YUN1cnNvciA9IG9u
ZWRhdGFDb25uZWN0aW9uRGF0YS5nZXRDdXJzb3IoKTsNCklEYXRhVXRpbC5wdXQoIG9uZWRhdGFD
b25uZWN0aW9uRGF0YUN1cnNvciwgImhvc3QiLCBvbmVkYXRhLmdldCgiaG9zdCIpLmFzU3RyaW5n
KCkgKTsNCklEYXRhVXRpbC5wdXQoIG9uZWRhdGFDb25uZWN0aW9uRGF0YUN1cnNvciwgInBvcnQi
LCBvbmVkYXRhLmdldCgicG9ydCIpLmFzU3RyaW5nKCApKTsNCklEYXRhVXRpbC5wdXQoIG9uZWRh
dGFDb25uZWN0aW9uRGF0YUN1cnNvciwgInJlc3RQYXRoIiwgb25lZGF0YS5nZXQoInJlc3RQYXRo
IikuYXNTdHJpbmcoICkpOw0Kb25lZGF0YUNvbm5lY3Rpb25EYXRhQ3Vyc29yLmRlc3Ryb3koKTsN
CklEYXRhVXRpbC5wdXQoIHBpcGVsaW5lQ3Vyc29yLCAib25lZGF0YUNvbm5lY3Rpb25EYXRhIiwg
b25lZGF0YUNvbm5lY3Rpb25EYXRhICk7DQpwaXBlbGluZUN1cnNvci5kZXN0cm95KCk7DQoJDQo=
</value>
</Values>
