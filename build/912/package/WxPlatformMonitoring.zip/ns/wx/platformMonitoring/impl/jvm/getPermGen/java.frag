<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getPermGen</value>
  <array name="sig" type="value" depth="1">
    <value>[o] field:0:required percentageUsed</value>
    <value>[o] field:0:required resultTxt</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">TWVtb3J5UG9vbE1YQmVhbiBwZXJtZ2VuQmVhbiA9IG51bGw7DQogICAgTGlzdDxNZW1vcnlQb29s
TVhCZWFuPiBiZWFucyA9IA0KICAgICAgICAgICAgTWFuYWdlbWVudEZhY3RvcnkuZ2V0TWVtb3J5
UG9vbE1YQmVhbnMoKTsNCiAgICBmb3IoTWVtb3J5UG9vbE1YQmVhbiBiZWFuIDogYmVhbnMpIHsN
CiAgICAgICAgaWYoYmVhbi5nZXROYW1lKCkudG9Mb3dlckNhc2UoKS5pbmRleE9mKCJwZXJtIGdl
biIpID49IDApIHsNCiAgICAgICAgICAgIHBlcm1nZW5CZWFuID0gYmVhbjsNCiAgICAgICAgICAg
IGJyZWFrOw0KICAgICAgICB9DQogICAgfQ0KDQogICAgTWVtb3J5VXNhZ2UgY3VycmVudFVzYWdl
ID0gcGVybWdlbkJlYW4uZ2V0VXNhZ2UoKTsNCiAgICBpbnQgcGVyY2VudGFnZVVzZWQgPSAoaW50
KSgoY3VycmVudFVzYWdlLmdldFVzZWQoKSAqIDEwMCkgDQogICAgICAgICAgICAvIGN1cnJlbnRV
c2FnZS5nZXRNYXgoKSk7DQogICAgSURhdGFVdGlsLnB1dChwaXBlbGluZS5nZXRDdXJzb3IoKSwg
InJlc3VsdFR4dCIsIG5ldyBEYXRlKCkgKyAiOiBQZXJtZ2VuICIgKyANCiAgICAgICAgICAgIGN1
cnJlbnRVc2FnZS5nZXRVc2VkKCkgKw0KICAgICAgICAgICAgIiBvZiAiICsgY3VycmVudFVzYWdl
LmdldE1heCgpICsNCiAgICAgICAgICAgICIgKCIgKyBwZXJjZW50YWdlVXNlZCArICIlKSIpOw0K
ICAgIElEYXRhVXRpbC5wdXQocGlwZWxpbmUuZ2V0Q3Vyc29yKCksICJtYXhQZXJtR2VuIiwgY3Vy
cmVudFVzYWdlLmdldE1heCgpICsgIiIpOw0KICAgIElEYXRhVXRpbC5wdXQocGlwZWxpbmUuZ2V0
Q3Vyc29yKCksICJ1c2VkUGVybUdlbiIsIGN1cnJlbnRVc2FnZS5nZXRVc2VkKCkgKyAiIik7DQog
ICAgSURhdGFVdGlsLnB1dChwaXBlbGluZS5nZXRDdXJzb3IoKSwgInBlcmNlbnRhZ2VVc2VkIiwg
cGVyY2VudGFnZVVzZWQgKyAiIik7DQoJDQo=</value>
</Values>
