<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getQueuedElementsJmsQueue</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:0:required RNAME</value>
    <value>[i] field:0:required queueName</value>
    <value>[o] field:0:required outstandingEvents</value>
    <value>[o] field:0:required queueStorageSize</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">dHJ5IHsNCgkNCgkvLyBwaXBlbGluZQ0KCUlEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlw
ZWxpbmUuZ2V0Q3Vyc29yKCk7DQoJU3RyaW5nCVJOQU1FID0gSURhdGFVdGlsLmdldFN0cmluZygg
cGlwZWxpbmVDdXJzb3IsICJSTkFNRSIgKTsNCglTdHJpbmcJcXVldWVOYW1lID0gSURhdGFVdGls
LmdldFN0cmluZyggcGlwZWxpbmVDdXJzb3IsICJxdWV1ZU5hbWUiICk7DQoJDQoJaWYoIFJOQU1F
ID09IG51bGwgfHwgIiIuZXF1YWxzKFJOQU1FKSApICB7DQoJCXRocm93IG5ldyBTZXJ2aWNlRXhj
ZXB0aW9uKCJSTkFNRSBtdXN0IG5vdCBiZSBlbXB0eS4gUHJvdmlkZSBsaWtlOiAnbnNwOi8vaG9z
dDpwb3J0Jy4iKTsNCgl9DQoJaWYoIHF1ZXVlTmFtZSA9PSBudWxsIHx8ICIiLmVxdWFscyhxdWV1
ZU5hbWUpICkgew0KCQl0aHJvdyBuZXcgU2VydmljZUV4Y2VwdGlvbigicXVldWVOYW1lIG11c3Qg
bm90IGJlIG51bGwuIik7DQoJfQ0KCQ0KCW5TZXNzaW9uQXR0cmlidXRlcyBuc2E9bmV3IG5TZXNz
aW9uQXR0cmlidXRlcyhSTkFNRSk7DQoJblNlc3Npb24gICAgICBteVNlc3Npb24gPSBuU2Vzc2lv
bkZhY3RvcnkuY3JlYXRlKG5zYSk7DQoJbXlTZXNzaW9uLmluaXQoKTsNCg0KCW5DaGFubmVsQXR0
cmlidXRlcyBhdHRyaWIgPSBuZXcgbkNoYW5uZWxBdHRyaWJ1dGVzKCk7DQogICAgYXR0cmliLnNl
dE5hbWUocXVldWVOYW1lKTsNCiAgICBuUXVldWUgcXVldWUgPSBteVNlc3Npb24uZmluZFF1ZXVl
KGF0dHJpYik7DQogICAgY29tLnBjYnN5cy5uaXJ2YW5hLmNsaWVudC5uUXVldWVEZXRhaWxzIGRl
dGFpbHMgPSBxdWV1ZS5nZXREZXRhaWxzKCk7DQogICAgSURhdGFVdGlsLnB1dChwaXBlbGluZUN1
cnNvciwgIm91dHN0YW5kaW5nRXZlbnRzIiwgZGV0YWlscy5nZXROb09mRXZlbnRzKCkgKyAiIik7
DQogICAgSURhdGFVdGlsLnB1dChwaXBlbGluZUN1cnNvciwgInF1ZXVlU3RvcmFnZVNpemUiLCBk
ZXRhaWxzLmdldFRvdGFsTWVtb3J5U2l6ZSgpICsgIiIpOw0KICAgIHBpcGVsaW5lQ3Vyc29yLmRl
c3Ryb3koKTsNCgkNCn0gY2F0Y2ggKEV4Y2VwdGlvbiBlKSB7DQoJLy8gVE9ETyBBdXRvLWdlbmVy
YXRlZCBjYXRjaCBibG9jaw0KCWUucHJpbnRTdGFja1RyYWNlKCk7DQoJdGhyb3cgbmV3IFNlcnZp
Y2VFeGNlcHRpb24oZSk7DQp9DQoNCgkNCg==</value>
</Values>
