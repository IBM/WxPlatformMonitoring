<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">contains</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:1:required stringArray</value>
    <value>[i] field:0:required value</value>
    <value>[o] field:0:required isIn</value>
  </array>
  <value name="subtype">unknown</value>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQpTdHJpbmdbXSAgICAgICBzdHJpbmdBcnJheSA9IElEYXRhVXRpbC5nZXRTdHJpbmdB
cnJheSggcGlwZWxpbmVDdXJzb3IsICJzdHJpbmdBcnJheSIgKTsNClN0cmluZyAgICAgICAgICAg
ICAgIHZhbHVlID0gSURhdGFVdGlsLmdldFN0cmluZyggcGlwZWxpbmVDdXJzb3IsICJ2YWx1ZSIg
KTsNCg0KaWYoIHN0cmluZ0FycmF5ID09IG51bGwgKSB7DQoJc3RyaW5nQXJyYXkgPSBuZXcgU3Ry
aW5nWzBdOw0KfQ0KU3RyaW5nIGNvbnRhaW5zID0gImZhbHNlIjsNCmZvciggU3RyaW5nIHN0cmlu
Z0VsZW0gOiBzdHJpbmdBcnJheSApIHsNCglpZiggc3RyaW5nRWxlbS5lcXVhbHModmFsdWUpICkg
IHsNCgkJY29udGFpbnMgPSAidHJ1ZSI7DQoJCWJyZWFrOw0KCX0NCn0NCklEYXRhVXRpbC5wdXQo
IHBpcGVsaW5lQ3Vyc29yLCAiaXNJbiIsIGNvbnRhaW5zICk7DQovLwkJDQovLwkJU2V0PFN0cmlu
Zz4gcyA9IG5ldyBIYXNoU2V0PFN0cmluZz4oKTsNCi8vCQlzLmFkZEFsbCggQXJyYXlzLmFzTGlz
dCggc3RyaW5nQXJyYXkpICk7DQovLwkJDQovLwkJSURhdGFVdGlsLnB1dCggcGlwZWxpbmVDdXJz
b3IsICJpc0luIiwgIiIgKyBzLmNvbnRhaW5zKCB2YWx1ZSApICk7DQpwaXBlbGluZUN1cnNvci5k
ZXN0cm95KCk7DQoJDQoJDQo=</value>
</Values>
