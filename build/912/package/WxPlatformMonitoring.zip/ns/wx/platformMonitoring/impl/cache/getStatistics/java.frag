<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getStatistics</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:0:required cacheManagerName</value>
    <value>[i] field:0:required cacheName</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgaWRjID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7DQpTdHJpbmcgY2FjaGVNYW5h
Z2VyTmFtZSA9IElEYXRhVXRpbC5nZXRTdHJpbmcoaWRjLCAiY2FjaGVNYW5hZ2VyTmFtZSIpOw0K
U3RyaW5nIGNhY2hlTmFtZSA9IElEYXRhVXRpbC5nZXRTdHJpbmcoaWRjLCAiY2FjaGVOYW1lIik7
DQoNCkNhY2hlIGNhY2hlID0gQ2FjaGVNYW5hZ2VyVXRpbC5nZXRDYWNoZU1hbmFnZXIoY2FjaGVN
YW5hZ2VyTmFtZSkuZ2V0Q2FjaGUoY2FjaGVOYW1lKTsNClN0cmluZyBzdGF0cyA9IGNhY2hlLmdl
dFN0YXRpc3RpY3MoKS50b1N0cmluZygpOw0KDQpTdHJpbmcgY29uZmlnID0gImdldE1heEVudHJp
ZXNMb2NhbEhlYXA6ICIgKyBjYWNoZS5nZXRDYWNoZUNvbmZpZ3VyYXRpb24oKS5nZXRNYXhFbnRy
aWVzTG9jYWxIZWFwKCkgKyANCgkJIiwgIGdldE1heEVsZW1lbnRzSW5NZW1vcnk6ICIgKyBjYWNo
ZS5nZXRDYWNoZUNvbmZpZ3VyYXRpb24oKS5nZXRNYXhFbGVtZW50c0luTWVtb3J5KCkgKyAiLCBl
dmljdGlvblBvbGljeTogIiArIGNhY2hlLmdldE1lbW9yeVN0b3JlRXZpY3Rpb25Qb2xpY3koKS5n
ZXROYW1lKCk7DQoNClN0cmluZyBuckVudHJpZXMgPSBjYWNoZS5nZXRLZXlzKCkuc2l6ZSgpICsg
IiI7DQoNCklEYXRhVXRpbC5wdXQoaWRjLCAic3RhdHMiLCBzdGF0cyk7DQpJRGF0YVV0aWwucHV0
KGlkYywgImNvbmZpZyIsIGNvbmZpZyk7DQpJRGF0YVV0aWwucHV0KGlkYywgIm5yRW50cmllcyIs
IG5yRW50cmllcyk7DQppZGMuZGVzdHJveSgpOw0K</value>
</Values>
