<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getQueuedElements</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:0:required RNAME</value>
    <value>[i] field:0:required queueName</value>
    <value>[o] field:0:required outstandingEvents</value>
    <value>[o] record:1:required sharedDurableOutstandingEvents</value>
    <value>[o] - field:0:required outstandingEvents</value>
    <value>[o] - field:0:required namedObject</value>
    <value>[o] field:0:required outstandingEventsSharedDurableMax</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">dHJ5IHsNCgkNCgkvLyBwaXBlbGluZQ0KCUlEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlw
ZWxpbmUuZ2V0Q3Vyc29yKCk7DQoJU3RyaW5nCVJOQU1FID0gSURhdGFVdGlsLmdldFN0cmluZygg
cGlwZWxpbmVDdXJzb3IsICJSTkFNRSIgKTsNCglTdHJpbmcJcXVldWVOYW1lID0gSURhdGFVdGls
LmdldFN0cmluZyggcGlwZWxpbmVDdXJzb3IsICJxdWV1ZU5hbWUiICk7DQoJDQoJaWYoIFJOQU1F
ID09IG51bGwgfHwgIiIuZXF1YWxzKFJOQU1FKSApICB7DQoJCXRocm93IG5ldyBTZXJ2aWNlRXhj
ZXB0aW9uKCJSTkFNRSBtdXN0IG5vdCBiZSBlbXB0eS4gUHJvdmlkZSBsaWtlOiAnbnNwOi8vaG9z
dDpwb3J0Jy4iKTsNCgl9DQoJaWYoIHF1ZXVlTmFtZSA9PSBudWxsIHx8ICIiLmVxdWFscyhxdWV1
ZU5hbWUpICkgew0KCQl0aHJvdyBuZXcgU2VydmljZUV4Y2VwdGlvbigicXVldWVOYW1lIG11c3Qg
bm90IGJlIG51bGwuIik7DQoJfQ0KCQ0KCW5TZXNzaW9uQXR0cmlidXRlcyBuc2E9bmV3IG5TZXNz
aW9uQXR0cmlidXRlcyhSTkFNRSk7DQoJblNlc3Npb24gICAgICBteVNlc3Npb24gPSBuU2Vzc2lv
bkZhY3RvcnkuY3JlYXRlKG5zYSk7DQoJbXlTZXNzaW9uLmluaXQoKTsNCgkNCgluQ2hhbm5lbEF0
dHJpYnV0ZXMgYXR0cmliID0gbmV3IG5DaGFubmVsQXR0cmlidXRlcygpOw0KICAgIGF0dHJpYi5z
ZXROYW1lKHF1ZXVlTmFtZSk7DQogICAgY29tLnBjYnN5cy5uaXJ2YW5hLmNsaWVudC5uRmluZFJl
c3VsdFtdIGZpbmRSZXN1bHQgPSBteVNlc3Npb24uZmluZChuZXcgbkNoYW5uZWxBdHRyaWJ1dGVz
W10ge2F0dHJpYn0pOw0KICAgIGlmKCBmaW5kUmVzdWx0Lmxlbmd0aCA9PSAwICkgew0KICAgIAl0
aHJvdyBuZXcgU2VydmljZUV4Y2VwdGlvbigiUWV1ZXUiICsgcXVldWVOYW1lKyAiIHdhcyBub3Qg
Zm91bmQgb24gcmVhbG0gIiArIFJOQU1FKTsNCiAgICB9DQogICAgaWYoIGZpbmRSZXN1bHRbMF0u
aXNDaGFubmVsKCkgKSB7DQogICAgCS8vIGlmIGl0IGlzIGEgY2hhbm5lbCwgdGhlbiBpdCBpcyBh
IGptcyB0b3BpYw0KICAgIAlJRGF0YVV0aWwucHV0KCBwaXBlbGluZUN1cnNvciwgImNoYW5uZWxO
YW1lIiwgcXVldWVOYW1lKTsNCiAgICAJZ2V0UXVldWVkRWxlbWVudHNDaGFubmVsKHBpcGVsaW5l
KTsNCiAgICB9IGVsc2UgaWYoIGZpbmRSZXN1bHRbMF0uaXNRdWV1ZSgpICkgew0KICAgIAkvLyB0
aGlzIGlzIGEgam1zIHF1ZXVlDQogICAgCWdldFF1ZXVlZEVsZW1lbnRzSm1zUXVldWUocGlwZWxp
bmUpOw0KICAgIH0gZWxzZSB7DQogICAgCXRocm93IG5ldyBTZXJ2aWNlRXhjZXB0aW9uKCJRdWV1
ZSAiICsgcXVldWVOYW1lICsgIiBvbiByZWFsbSAiICsgUk5BTUUgKyAiIGlzIG5laXRoZXIgcXVl
dWUgbm9yIGNoYW5uZWwuIik7DQogICAgfQ0KICAgIHBpcGVsaW5lQ3Vyc29yLmRlc3Ryb3koKTsN
CgkNCn0gY2F0Y2ggKEV4Y2VwdGlvbiBlKSB7DQoJLy8gVE9ETyBBdXRvLWdlbmVyYXRlZCBjYXRj
aCBibG9jaw0KCWUucHJpbnRTdGFja1RyYWNlKCk7DQoJdGhyb3cgbmV3IFNlcnZpY2VFeGNlcHRp
b24oZSk7DQp9DQoNCgkNCg==</value>
</Values>
