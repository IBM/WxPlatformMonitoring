<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">tracePipelineToString</value>
  <array name="sig" type="value" depth="1">
    <value>[i] record:0:required doc</value>
    <value>[i] field:1:required ignore</value>
    <value>[o] field:0:required pipelineAsString</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgcGlwZWxpbmVDID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7DQpTdHJpbmdbXSBp
Z25vcmUgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nQXJyYXkocGlwZWxpbmVDLCAiaWdub3JlIik7DQpq
YXZhLnV0aWwuU2V0PFN0cmluZz4gaWdub3JlU2V0ID0gbmV3IGphdmEudXRpbC5IYXNoU2V0PFN0
cmluZz4oKTsNCmlmKCBpZ25vcmUgIT0gbnVsbCApIHsNCglmb3IoIFN0cmluZyBpIDogaWdub3Jl
ICkgew0KCQlpZ25vcmVTZXQuYWRkKGkpOw0KCX0NCn0NCklEYXRhVXRpbC5yZW1vdmUocGlwZWxp
bmVDLCAiaWdub3JlIik7DQpTdHJpbmdCdWlsZGVyIGJ1ZmZlciA9IG5ldyBTdHJpbmdCdWlsZGVy
KCk7IA0KLy8gdXNlZCBhcyB0cmVlIHRvIGRyaWxsIGRvd24gdGhlIHBpcGVsaW5lIA0KamF2YS51
dGlsLkhhc2h0YWJsZTxPYmplY3QsIE9iamVjdD4gdGFibGUgPSBuZXcgamF2YS51dGlsLkhhc2h0
YWJsZTxPYmplY3QsIE9iamVjdD4oKTsNCnRhYmxlLnB1dChwaXBlbGluZSwgcGlwZWxpbmUpOyAN
CmR1bXBJRGF0YShidWZmZXIsIDAsIHBpcGVsaW5lLCAwLCB0YWJsZSwgaWdub3JlU2V0KTsgDQoN
CnBpcGVsaW5lQy5pbnNlcnRBZnRlcigicGlwZWxpbmVBc1N0cmluZyIsIGJ1ZmZlci50b1N0cmlu
ZygpKTsNCg0KcGlwZWxpbmVDLmRlc3Ryb3koKTsgDQo=</value>
</Values>
