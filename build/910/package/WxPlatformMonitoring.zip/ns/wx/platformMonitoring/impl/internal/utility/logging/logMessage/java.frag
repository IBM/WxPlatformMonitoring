<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">logMessage</value>
  <array name="sig" type="value" depth="1">
    <value>[i] field:0:required logMessage</value>
    <value>[i] field:0:required severity {"TRACE","DEBUG","INFO","WARN","ERROR","FATAL"}</value>
    <value>[i] field:0:optional logger</value>
  </array>
  <value name="sigtype">java 3.5</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQpTdHJpbmcJbG9nTWVzc2FnZSA9IElEYXRhVXRpbC5nZXRTdHJpbmcoIHBpcGVsaW5l
Q3Vyc29yLCAibG9nTWVzc2FnZSIgKTsNClN0cmluZwlzZXZlcml0eSA9IElEYXRhVXRpbC5nZXRT
dHJpbmcoIHBpcGVsaW5lQ3Vyc29yLCAic2V2ZXJpdHkiICk7DQpTdHJpbmcgbG9nZ2VyID0gSURh
dGFVdGlsLmdldFN0cmluZyggcGlwZWxpbmVDdXJzb3IsICJsb2dnZXIiICk7DQpTdHJpbmcgcHJl
Zml4ID0gSURhdGFVdGlsLmdldFN0cmluZyggcGlwZWxpbmVDdXJzb3IsICJwcmVmaXgiICk7DQpw
aXBlbGluZUN1cnNvci5kZXN0cm95KCk7DQoNCmlmKCBwcmVmaXggIT0gbnVsbCApIHsNCglsb2dN
ZXNzYWdlID0gcHJlZml4ICsgIiAiICsgbG9nTWVzc2FnZTsNCn0NCg0KaWYoIGxvZ2dlciA9PSBu
dWxsICkgew0KCWxvZ2dlciA9ICJ3eC5wbGF0Zm9ybU1vbml0b3JpbmciOw0KfQ0KDQpMb2dnZXIg
bG9nID0gTG9nZ2VyLmdldExvZ2dlcihsb2dnZXIpOw0KaWYoIHNldmVyaXR5LmVxdWFsc0lnbm9y
ZUNhc2UoIndhcm4iKSApIHsNCglsb2cud2Fybihsb2dNZXNzYWdlKTsNCn0gZWxzZSBpZiggc2V2
ZXJpdHkuZXF1YWxzSWdub3JlQ2FzZSgiZXJyb3IiKSApIHsNCglsb2cuZXJyb3IobG9nTWVzc2Fn
ZSk7DQp9IGVsc2UgaWYoIHNldmVyaXR5LmVxdWFsc0lnbm9yZUNhc2UoImZhdGFsIikgKSB7DQoJ
bG9nLmZhdGFsKGxvZ01lc3NhZ2UpOw0KfSBlbHNlIGlmKCBzZXZlcml0eS5lcXVhbHNJZ25vcmVD
YXNlKCJpbmZvIikgKSB7DQoJbG9nLmluZm8obG9nTWVzc2FnZSk7DQp9IGVsc2UgaWYoIHNldmVy
aXR5LmVxdWFsc0lnbm9yZUNhc2UoImRlYnVnIikgKSB7DQoJbG9nLmRlYnVnKGxvZ01lc3NhZ2Up
Ow0KfSBlbHNlIHsNCglsb2cudHJhY2UobG9nTWVzc2FnZSk7DQp9DQoJDQo=</value>
</Values>
